
The Agents
==========

The HSA agents found in the system can be listed and accessed via:

.. attribute:: numba.roc.agents
