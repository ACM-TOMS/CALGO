.. dill documentation master file

dill package documentation
==========================

.. automodule:: dill
    :members:
    :undoc-members:
    :private-members:
    :special-members:
    :show-inheritance:

.. toctree::
    :maxdepth: 2
    :caption: Contents:

    dill
    scripts

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
