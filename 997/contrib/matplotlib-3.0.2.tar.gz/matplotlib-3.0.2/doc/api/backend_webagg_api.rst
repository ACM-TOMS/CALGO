
:mod:`matplotlib.backends.backend_webagg`
=========================================

.. note::
   The WebAgg backend is not documented here, in order to avoid adding Tornado
   to the doc build requirements.

.. .. automodule:: matplotlib.backends.backend_webagg
..    :members:
..    :undoc-members:
..    :show-inheritance:
