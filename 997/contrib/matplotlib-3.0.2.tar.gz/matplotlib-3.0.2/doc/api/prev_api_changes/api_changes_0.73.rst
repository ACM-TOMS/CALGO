Changes for 0.73
================

.. code-block:: text

  - Removed deprecated ColormapJet and friends

  - Removed all error handling from the verbose object

  - figure num of zero is now allowed
