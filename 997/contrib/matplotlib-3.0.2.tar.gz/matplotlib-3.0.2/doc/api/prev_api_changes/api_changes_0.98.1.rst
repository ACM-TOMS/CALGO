Changes for 0.98.1
==================

* Removed broken :mod:`matplotlib.axes3d` support and replaced it with
  a non-implemented error pointing to 0.91.x
