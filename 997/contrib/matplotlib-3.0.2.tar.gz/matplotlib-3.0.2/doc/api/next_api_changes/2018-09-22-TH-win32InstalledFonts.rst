matplotlib.font_manager.win32InstalledFonts return value
````````````````````````````````````````````````````````

`matplotlib.font_manager.win32InstalledFonts` returns an empty list instead
of None if no fonts are found.
