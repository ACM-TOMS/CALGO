
:mod:`matplotlib.backends.backend_mixed`
========================================

.. automodule:: matplotlib.backends.backend_mixed
   :members:
   :undoc-members:
   :show-inheritance:
