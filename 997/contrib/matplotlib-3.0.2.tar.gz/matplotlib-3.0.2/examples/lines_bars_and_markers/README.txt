.. _lines_bars_and_markers_example:

Lines, bars and markers
=======================
