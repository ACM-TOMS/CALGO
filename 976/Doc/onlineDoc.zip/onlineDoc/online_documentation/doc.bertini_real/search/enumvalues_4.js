var searchData=
[
  ['edge',['EDGE',['../dc/df9/bertini__extensions_8hpp.xhtml#adc29c2ff13d900c2f185ee95427fb06caa622cbc12b78e3e883dd7b3217088a66',1,'bertini_extensions.hpp']]]
];
