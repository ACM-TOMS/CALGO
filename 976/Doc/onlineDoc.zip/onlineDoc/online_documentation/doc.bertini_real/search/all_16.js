var searchData=
[
  ['zero',['zero',['../d4/da5/classmidpoint__eval__data__mp.xhtml#a8dfca3b55d03f970a9608c2ba216746e',1,'midpoint_eval_data_mp::zero()'],['../d9/dbf/classmidpoint__eval__data__d.xhtml#a7533c3ac80288250fc334c92e62cf8df',1,'midpoint_eval_data_d::zero()']]],
  ['zero_5ffull_5fprec',['zero_full_prec',['../d4/da5/classmidpoint__eval__data__mp.xhtml#aecccb781fb81cb47d5461a70102e8bae',1,'midpoint_eval_data_mp']]],
  ['zerothresh_5f',['zerothresh_',['../dc/dbc/class_vertex_set.xhtml#ad3d9ed3aa0affc730f731ee7e585ce49',1,'VertexSet']]]
];
