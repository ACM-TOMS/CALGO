var searchData=
[
  ['quick_5frun',['quick_run',['../d8/d07/class_bertini_real_config.xhtml#ab1205b30d0d6b2cb31c9d6db64958295',1,'BertiniRealConfig::quick_run()'],['../d8/d07/class_bertini_real_config.xhtml#a04342cf68e0e3d28a147629e52b78892',1,'BertiniRealConfig::quick_run(int new_val)']]]
];
