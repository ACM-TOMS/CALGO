var searchData=
[
  ['vec_5fd',['VEC_D',['../dc/df9/bertini__extensions_8hpp.xhtml#adc29c2ff13d900c2f185ee95427fb06ca9a6a55c31afccbd04a72ba0c425bb9c9',1,'bertini_extensions.hpp']]],
  ['vec_5fmp',['VEC_MP',['../dc/df9/bertini__extensions_8hpp.xhtml#adc29c2ff13d900c2f185ee95427fb06ca12503028f06d0a2427e555dca9be8fbb',1,'bertini_extensions.hpp']]],
  ['vec_5frat',['VEC_RAT',['../dc/df9/bertini__extensions_8hpp.xhtml#adc29c2ff13d900c2f185ee95427fb06ca264efad8f53ead6a317cf36110156c11',1,'bertini_extensions.hpp']]],
  ['vertex',['VERTEX',['../dc/df9/bertini__extensions_8hpp.xhtml#adc29c2ff13d900c2f185ee95427fb06ca2e4d5495bd9d476f78962cebe074ebbd',1,'bertini_extensions.hpp']]],
  ['vertex_5fset',['VERTEX_SET',['../dc/df9/bertini__extensions_8hpp.xhtml#adc29c2ff13d900c2f185ee95427fb06ca139b465ee4f4e21baf9399790fa5ad24',1,'bertini_extensions.hpp']]]
];
