var searchData=
[
  ['tol_5fdouble_5fprecision',['TOL_DOUBLE_PRECISION',['../dc/df9/bertini__extensions_8hpp.xhtml#abf1b5b46eaa3b9273cb917a241582992',1,'bertini_extensions.hpp']]],
  ['tol_5fmp',['TOL_MP',['../dc/df9/bertini__extensions_8hpp.xhtml#a3c0188247ea4336078190f798ecb3e4f',1,'bertini_extensions.hpp']]]
];
