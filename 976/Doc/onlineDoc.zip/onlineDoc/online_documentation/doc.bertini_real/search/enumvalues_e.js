var searchData=
[
  ['unused',['UNUSED',['../dc/df9/bertini__extensions_8hpp.xhtml#adc29c2ff13d900c2f185ee95427fb06caa09b651ef326a9d8efcee5cc5b720ab4',1,'bertini_extensions.hpp']]]
];
