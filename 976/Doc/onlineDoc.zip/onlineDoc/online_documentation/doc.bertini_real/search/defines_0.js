var searchData=
[
  ['largechange_5fdoubleprecision',['LARGECHANGE_DOUBLEPRECISION',['../dc/df9/bertini__extensions_8hpp.xhtml#a7cc481f460dcd8501f7be78949d55bbc',1,'bertini_extensions.hpp']]],
  ['largechange_5fmp',['LARGECHANGE_MP',['../dc/df9/bertini__extensions_8hpp.xhtml#ade0cab2f0c8edf903f4b89181d0ad2ad',1,'bertini_extensions.hpp']]]
];
