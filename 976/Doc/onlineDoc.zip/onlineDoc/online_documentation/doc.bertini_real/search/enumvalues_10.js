var searchData=
[
  ['witness_5fset',['WITNESS_SET',['../dc/df9/bertini__extensions_8hpp.xhtml#adc29c2ff13d900c2f185ee95427fb06ca37a45c10bd57e5efa004781bf8a3a6ff',1,'bertini_extensions.hpp']]]
];
