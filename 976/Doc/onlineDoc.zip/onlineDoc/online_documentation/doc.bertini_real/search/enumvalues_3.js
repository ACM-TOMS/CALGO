var searchData=
[
  ['data_5ftransmission',['DATA_TRANSMISSION',['../dc/df9/bertini__extensions_8hpp.xhtml#a726ca809ffd3d67ab4b8476646f26635a0d208c8c6e9a5ba76a686bf785fbed5a',1,'bertini_extensions.hpp']]],
  ['decomposition',['DECOMPOSITION',['../dc/df9/bertini__extensions_8hpp.xhtml#adc29c2ff13d900c2f185ee95427fb06ca18a09e1c53fa4f18f2132ed11514f6dd',1,'bertini_extensions.hpp']]],
  ['detjactodetjac',['DETJACTODETJAC',['../dc/df9/bertini__extensions_8hpp.xhtml#a99fb83031ce9923c84392b4e92f956b5a3e89c167bd3d34ec31b54490fc41df89',1,'bertini_extensions.hpp']]]
];
