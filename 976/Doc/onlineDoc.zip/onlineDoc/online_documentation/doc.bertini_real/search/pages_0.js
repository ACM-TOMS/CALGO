var searchData=
[
  ['bertini_20real',['Bertini Real',['../index.xhtml',1,'']]]
];
