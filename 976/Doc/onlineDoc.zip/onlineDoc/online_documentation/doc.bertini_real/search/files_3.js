var searchData=
[
  ['edge_2ehpp',['edge.hpp',['../d4/ddf/edge_8hpp.xhtml',1,'']]]
];
