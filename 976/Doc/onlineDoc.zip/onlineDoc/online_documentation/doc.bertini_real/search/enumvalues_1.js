var searchData=
[
  ['bertini_5fmain',['BERTINI_MAIN',['../dc/df9/bertini__extensions_8hpp.xhtml#a99fb83031ce9923c84392b4e92f956b5ad513455b1b7746548ed510b28590014e',1,'bertini_extensions.hpp']]],
  ['bertinireal',['BERTINIREAL',['../dd/df7/program_configuration_8hpp.xhtml#abed82baf7f470b522273a3e37c24c600a3fbd71a716a048e12cb2a4ce9522fe76',1,'programConfiguration.hpp']]]
];
