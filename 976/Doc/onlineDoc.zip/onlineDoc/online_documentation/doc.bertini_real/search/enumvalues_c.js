var searchData=
[
  ['sphere_5fsolver',['SPHERE_SOLVER',['../dc/df9/bertini__extensions_8hpp.xhtml#a99fb83031ce9923c84392b4e92f956b5a0e81da7b54bedc40f523c3c503f09b35',1,'bertini_extensions.hpp']]],
  ['successful',['SUCCESSFUL',['../dc/df9/bertini__extensions_8hpp.xhtml#a06fc87d81c62e9abb8790b6e5713c55ba0c677fdda6b6e8ddc7a7c760b22ab6d2',1,'bertini_extensions.hpp']]],
  ['surface',['SURFACE',['../dc/df9/bertini__extensions_8hpp.xhtml#adc29c2ff13d900c2f185ee95427fb06caec3093f5673be2548cc7091279b429e2',1,'bertini_extensions.hpp']]],
  ['system_5fcrit',['SYSTEM_CRIT',['../dc/df9/bertini__extensions_8hpp.xhtml#adf764cbdea00d65edcd07bb9953ad2b7a6b11fa9189388b7b816bb5b0dc3d6478',1,'bertini_extensions.hpp']]],
  ['system_5frandomizer',['SYSTEM_RANDOMIZER',['../dc/df9/bertini__extensions_8hpp.xhtml#adc29c2ff13d900c2f185ee95427fb06ca006b98d9cd3810c8132b4388b42c2caf',1,'bertini_extensions.hpp']]],
  ['system_5fsphere',['SYSTEM_SPHERE',['../dc/df9/bertini__extensions_8hpp.xhtml#adf764cbdea00d65edcd07bb9953ad2b7a950aa10a96946d1a87225b1275a78aaa',1,'bertini_extensions.hpp']]]
];
