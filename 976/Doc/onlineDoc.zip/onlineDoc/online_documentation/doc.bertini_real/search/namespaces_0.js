var searchData=
[
  ['color',['color',['../d7/dfd/namespacecolor.xhtml',1,'']]]
];
