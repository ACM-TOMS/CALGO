var searchData=
[
  ['vertextype',['VertexType',['../dc/df9/bertini__extensions_8hpp.xhtml#a30e5cd355d66819294b056173a3f89df',1,'bertini_extensions.hpp']]]
];
