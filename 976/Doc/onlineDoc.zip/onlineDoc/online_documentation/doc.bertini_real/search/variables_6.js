var searchData=
[
  ['gamma',['gamma',['../de/d1d/class_solver_multiple_precision.xhtml#a3db6e13985adcb813604917a89118556',1,'SolverMultiplePrecision::gamma()'],['../d2/d1e/class_solver_double_precision.xhtml#a3ee7726145a8a908e3024441e5067f3e',1,'SolverDoublePrecision::gamma()']]],
  ['gamma_5frat',['gamma_rat',['../de/d1d/class_solver_multiple_precision.xhtml#a83e62ccf8474cecff9e56359d765f273',1,'SolverMultiplePrecision']]]
];
