var searchData=
[
  ['isosingular_2ecpp',['isosingular.cpp',['../d7/df8/isosingular_8cpp.xhtml',1,'']]],
  ['isosingular_2ehpp',['isosingular.hpp',['../d4/d35/isosingular_8hpp.xhtml',1,'']]]
];
