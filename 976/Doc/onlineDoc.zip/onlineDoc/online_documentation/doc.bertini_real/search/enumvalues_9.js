var searchData=
[
  ['nullspace',['NULLSPACE',['../dc/df9/bertini__extensions_8hpp.xhtml#a99fb83031ce9923c84392b4e92f956b5af6efde50cf8c41d3f94eaa23718990fc',1,'bertini_extensions.hpp']]],
  ['numpackets',['NUMPACKETS',['../dc/df9/bertini__extensions_8hpp.xhtml#a726ca809ffd3d67ab4b8476646f26635a94ca86c87b9d84c795adeda29b0ab8ea',1,'bertini_extensions.hpp']]]
];
