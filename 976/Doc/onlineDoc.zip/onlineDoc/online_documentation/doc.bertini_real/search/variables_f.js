var searchData=
[
  ['quick_5frun_5f',['quick_run_',['../d8/d07/class_bertini_real_config.xhtml#ad8864d9f930dde647fe038c44844b282',1,'BertiniRealConfig']]]
];
