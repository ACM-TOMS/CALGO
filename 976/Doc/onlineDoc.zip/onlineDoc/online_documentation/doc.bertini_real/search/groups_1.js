var searchData=
[
  ['mpi_20bcasts_20_28sends_20and_20receives_29',['MPI Bcasts (sends and receives)',['../db/d99/group__bcast.xhtml',1,'']]],
  ['mpi_2denabled_20classes',['MPI-enabled classes',['../db/d6d/group__mpienabled.xhtml',1,'']]],
  ['mpi_20receives',['MPI Receives',['../d8/d86/group__receive.xhtml',1,'']]],
  ['mpi_20sends',['MPI Sends',['../d5/d2a/group__send.xhtml',1,'']]]
];
