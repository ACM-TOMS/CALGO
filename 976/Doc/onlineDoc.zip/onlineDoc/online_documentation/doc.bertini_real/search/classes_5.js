var searchData=
[
  ['linearholder',['LinearHolder',['../da/dfe/class_linear_holder.xhtml',1,'']]]
];
