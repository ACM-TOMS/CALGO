#include <iostream>
#include <iomanip>
using namespace std;

#include "MpIeee.hh"
#include "ArithmosIO.hh"

int main(){
    MpIeee *const k1=  state->k1;
    MpIeee *const k2=  state->k2;
    MpIeee *const k3=  state->k3;
    MpIeee *const ytmp=  state->ytmp;
}