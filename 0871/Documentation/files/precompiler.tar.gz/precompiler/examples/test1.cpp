int main(){
    double *const k1 = state->k1;
    double *const k2 = state->k2;
    double *const k3 = state->k3;
    double *const ytmp = state->ytmp;
}