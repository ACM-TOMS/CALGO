
int  matrix_print_off (int nr, int nc, double **A);
int  vector_print_off (int nr, double *x);
void gauss(double **a, double *b, double *x, int n);

int  matrix_print_off (int nr, int nc, double **A);
int  vector_print_off (int nr, double x);
void gauss(double **a, double *b, double *x, int n);

