#include <iostream>

#define BASE float

int main(){
  BASE a=4;
  BASE b;
  
  b=3;
  
  return 0;
}