
int main(){
  int a;
  float value=123.4;
  a = value;

  return 0;
}

