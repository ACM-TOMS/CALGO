#include <stdio.h>

int main(){
  float a=12345;
  float b=0.345;
  a=a+1;
  printf("a=%f\n",a);
  printf("b=%f\n",b);
}

