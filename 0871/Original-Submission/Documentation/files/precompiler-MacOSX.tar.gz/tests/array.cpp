int main(){
  int b=4;
  int a[5]={1,2,3,4,5};
  a[2]=12;
  if(a[3]==0) cout<<"zero"<<endl;
  int b[3][3];
  b[1][2]=4;
  if(b[1][2]>3) cout<<"trivial"<<endl;
  return 0;
}

