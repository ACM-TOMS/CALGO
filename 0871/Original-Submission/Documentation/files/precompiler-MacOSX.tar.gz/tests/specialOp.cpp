#include <iostream>
using namespace std;
int main(){
  int a = 3 >? 4;
  cout<<"a="<<a<<endl;
}

