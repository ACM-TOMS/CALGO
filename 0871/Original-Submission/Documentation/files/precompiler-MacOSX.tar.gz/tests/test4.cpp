

int main(){
  int a=3+2;
  float b=3.2+a;

  a=3.3;
  b=3;
}


