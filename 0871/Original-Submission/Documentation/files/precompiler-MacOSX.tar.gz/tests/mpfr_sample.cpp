#include <iostream>
using namespace std;

int main(){
  float a=12345;
  float b=0.345;
  a=a+1;
  cout<<"a="<<a<<endl;
  cout<<"b="<<b<<endl;
}

