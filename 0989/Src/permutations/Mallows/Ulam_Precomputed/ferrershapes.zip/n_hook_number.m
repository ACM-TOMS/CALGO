function [YoungTable,YoungCount,count,n_hook] = n_hook_number(partition)
n = size(partition,2);
YoungTable = zeros(n);
YoungCount = zeros(n);

count = 0;
for j=1:n,
     for k=1:partition(n-j+1),          
          count = count+1;
          YoungTable(count,1:n-j+1) = 1;          
     end
end

[row,col] = find(YoungTable==1);
n_hook = 1;
for i=1:size(row,1),
  YoungCount(row(i),col(i))  = sum(YoungTable(row(i),col(i):end)) + sum(YoungTable(row(i):end,col(i)))-1;
  n_hook = n_hook*YoungCount(row(i),col(i));
end  

